import React from 'react'

// function Food(props) {
//   console.log(props);
//   return (
//     <div>Food {props.propsName} , {props.propsName2} , {props.propsName3}</div>
//   )
// }

// export default Food;

// function Food(props) { //구조분해할당1
//   console.log(props);
//   const {propsName,propsName2,propsName3} = props;
//   return (
//     <div>Food {propsName} , {propsName2} , {propsName3}</div>
//   )
// }

// export default Food;

function Food({propsName,propsName2,propsName3}) { //구조분해할당2
  return (
    <div>Food {propsName} , {propsName2} , {propsName3}</div>
  )
}

export default Food;