import React, { Component } from 'react'

export class Cake extends Component {
  constructor(props) {
    super(props);
  }

state = {
  price: 10000,
  discountPrice: 0,
}
discountPrice = () => {
  this.setState({discountPrice:this.state.price*0.7 })
}

  render() {
    return (
      <>
        <div>
          <h1>Cake 가격은 {this.state.price}입니다.</h1>
          <h2>할인가격은 {this.state.discountPrice}입니다.</h2>
          <button onClick={this.discountPrice}>할인</button>
        </div>
      </>
    )
  }
}

export default Cake