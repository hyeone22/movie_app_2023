//클래스형 컴포넌트 rce
// import React, { Component } from 'react'

// export class Macaron extends Component {
//   render() {
//     return (
//       <div>Macaron</div>
//     )
//   }
// }

// export default Macaron;

//함수형 컴포넌트 rfce
import React from 'react'

// function Macaron(props) {
//   console.log(props)
//   return (
//     <div>
//       <h1>No.{props.propsid} </h1>
//       <h2>Name:{props.propsname} </h2>
//       <img src={props.propsimage} alt="" />
//     </div>
//   )
// }

// export default Macaron;
// function Macaron(props) { //구조분해할당1
//   console.log(props);
//   const {propsid,propsname,propsimage} = props;
//   return (
//     <div>
//       <h1>No.{propsid} </h1>
//       <h2>Name:{propsname} </h2>
//       <img src={propsimage} alt="" />
//     </div>
//   )
// }

// export default Macaron;

function Macaron({propsid,propsname,propsimage}) { //구조분해할당2
  return (
    <div>
      <h1>No.{propsid} </h1>
      <h2>Name:{propsname} </h2>
      <img src={propsimage} alt="" />
    </div>
  )
}

export default Macaron;